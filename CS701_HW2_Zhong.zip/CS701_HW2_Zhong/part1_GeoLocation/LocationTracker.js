 (function() {

 window.onload = init;

// default counter for updating location
var counter = 0;
// current location
var latitude, longitude;
// Google map
var map = null;
// Path
var path = [];
// default last maker
var lastMarker;

function init() {
	var startButton = document.getElementById("startButton");
	startButton.onclick = startTrackingLocation;
}

function startTrackingLocation() {

    // asynchronous call with callback success,
    // error functions and options specified

    var options = {
        enableHighAccuracy : true,
        timeout : 50000,
        maximumAge : 0
    };

    navigator.geolocation.getCurrentPosition(displayLocation, handleError, options);
    // grey out starbutton
    document.getElementById("startButton").disabled = true;
}

// show initial location and then start the auto updates to the coordinates
function displayLocation(position) {
// get current
    latitude = position.coords.latitude;
    longitude = position.coords.longitude;

    // setup inital values for the coordinates
    document.getElementById("counter").innerHTML = "Update#: " + counter;
    document.getElementById("latitude").innerHTML = "Start Latitude: " + latitude;
    document.getElementById("longitude").innerHTML = "Start Longitude: " + longitude;
    document.getElementById("currentLatitude").innerHTML = "Current Latitude: " + latitude;
    document.getElementById("currentLongitude").innerHTML = "Current Longitude: " + longitude;

    showOnMap(position.coords);
    // for 5 sec, update map
    window.setInterval(updateLocation, 5000);
}

function handleError(error) {
    switch(error.code) {
        case 1:
            updateStatus("The user denied permission");
            break;
        case 2:
            updateStatus("Position is unavailable");
            break;
        case 3:
            updateStatus("Timed out");
            break;
    }
}

function updateStatus(message) {
    document.getElementById("status").innerHTML =
        "<strong>Error</strong>: " + message;
}

//  open map
function showOnMap(pos) {

    var mapOptions = {
        zoom: 15,
        center: googlePosition,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    var googlePosition =
        new google.maps.LatLng(pos.latitude, pos.longitude);

    map = new google.maps.Map(document.getElementById("map"), mapOptions);

    // add the marker to the map
    var title = "Current (first) Location";
    var content = "lat: " + pos.latitude +
                  ", long: " + pos.longitude;

    addMarker(map, googlePosition, title, content);
}

// add  marker to each position
function addMarker(map, pos, title, content) {
    var options = {
        position: pos,
        map: map,
        title: title,
        clickable: true
    };
    var marker = new google.maps.Marker(options);

    var popupWindowOptions = {
        content: content,
        position: pos
    };

    var popupWindow = new google.maps.InfoWindow(popupWindowOptions);

    google.maps.event.addListener(marker, 'click', function() {
        popupWindow.open(map);
    });
    return marker;
}


function updateLocation()
{
counter += 1;
// reset path
    path = [];
    document.getElementById("counter").innerHTML = "Update#: " + counter;

    // first point
    var latlong = new google.maps.LatLng(latitude, longitude);
    path.push(latlong);

    // update by adding randoms to current
    random1 = Math.random() / 100;
    random2 = Math.random() / 100;
    latitude += random1;
    longitude -= random2;

    document.getElementById("currentLatitude").innerHTML =
            "Current Latitude: " + latitude + " (+" + random1 + ")";
    document.getElementById("currentLongitude").innerHTML =
            "Current Longitude: " + longitude + " (-" + random2 + ")";

    latlong = new google.maps.LatLng(latitude, longitude);
    path.push(latlong);

    var line = new google.maps.Polyline({
        path : path,
        strokeColor : '#0000ff',
        strokeOpacity : 1.0,
        strokeWeight : 3
    });
    line.setMap(map);

    map.panTo(latlong);

    // when new marker is created, add marker
    if (lastMarker)
        lastMarker.setMap(null);
    lastMarker = addMarker(map, latlong, "new location", "new lat:"+ latitude + ", new lon:" + longitude);
}



})();