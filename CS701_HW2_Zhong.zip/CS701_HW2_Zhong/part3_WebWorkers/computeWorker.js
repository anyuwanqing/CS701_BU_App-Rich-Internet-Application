self.onmessage = messageHandler;

function messageHandler(e) {
    var data = e.data;

    var sum = 0;
    var start = parseInt(e.data.start);
    var end = parseInt(e.data.end);
    var index = parseInt(e.data.index);

    // compute the sum of squares
    for (var i=start; i<end; i++){
        sum += i*i
    }
    data.result = sum;

  var result = {index: index, start: start, end: end, result: sum};
  console.log(sum)
  // result is sent as a JSON object having start, end, and result properties
     postMessage(result);

}

