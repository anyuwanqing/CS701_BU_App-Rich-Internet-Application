(function() {

    window.onload = init;


// default settings
    var startButton;
    var worker;

    var dataArr = [];
    var total = 0;

    var localStorageArr = [];
    var rangeArr = [];

    var error = document.getElementById("error");
    var sum = document.getElementById('sum')

    function init() {
    	startButton = document.getElementById("startButton");
    	startButton.onclick = sendData;
    }


    // Complete the following code

    function sendData(e) {
        startButton.disabled = true;

        var workers = document.getElementById("numWorkers").value;
        var end = document.getElementById("range").value;

        // shift end point
        shiftEnd(1, end,workers)
        // new worker
        for (var i=0; i<workers; i++) {
            worker = new Worker('computeWorker.js');
            //event listen to respond mesage
            worker.addEventListener('message',handleReceipt,false)

// send from the range
            worker.postMessage({
                index: i,
                start: rangeArr[i].start,
                end: rangeArr[i].end
            })
        }
    }

    function handleReceipt(event) {
            dataArr.push(event.data);

            total += event.data.result;
            document.getElementById('sum').innerHTML = total;
            console.log("total "+ total)


            // add new worker's items and local storage items
            localStorage.setItem('results', JSON.stringify(dataArr))
            var worker_items = document.getElementById('items');
            var worker_li = document.createElement('li');
            worker_li.appendChild(document.createTextNode(JSON.stringify(event.data)));
            worker_items.appendChild(worker_li);

            var localStorage_items = document.getElementById('storageItems');
            var localStorage_li = document.createElement('li');

            localStorageArr.push(JSON.parse(localStorage.results));


            // handle local storage results
            for (var i=0; i<localStorageArr.length; i++) {
                var resultObjInLS = JSON.stringify(localStorageArr[i][i]);
                localStorage_li.appendChild(document.createTextNode(resultObjInLS) );

                localStorage_items.appendChild(localStorage_li);
            }

        }

    // Feel free to add any helper methods

    function shiftEnd(start, end, workers) {

        // method to find the range split
        let rangeSplit = Math.floor((end - start)/(workers-1));
        /*console.log(rangeSplit)*/
        //for loop to push the objects to the array for use by the workers
        for (var i=0; start<end; i++) {
            newEnd = start + rangeSplit;
            rangeArr.push({start: start,end: newEnd})
            start += 1
        }
    }
})();























