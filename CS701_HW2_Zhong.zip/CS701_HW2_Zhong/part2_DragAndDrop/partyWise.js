window.onload = init;

// variables for drag and drop actions
var src, target, msg, sourceId, republicans, democrats;

// called on page load
function init() {
  // get local
  var localStorageSenators = localStorage.getItem("senators");
  console.log('localStorageSenators', localStorageSenators);

    // local storage keeps track of a list of senators, and their vote status

    //localStorageSenators = null;
  // if data is not already in browsers local storage get from xml
  if (localStorageSenators == null) {
    loadFromXml();

    // if local is not empty, get from local
  } else {
    // else data aleady in local storage, convert it into a JavaScript object
    var senators = JSON.parse(localStorageSenators);
    loadFromLocalStorage(senators);

    // populate html elements with the senators who voted already
    addSenatorsWhoVoted();
  }

  msg = document.getElementById("msg");
  src = document.getElementById("members");
  target = document.getElementById("dropLists");
  republicans = document.getElementById("republicans");
  democrats = document.getElementById("democrats");

  // Add event handlers for the source
  src.ondragstart = dragStartHandler;
  src.ondragend = dragEndHandler;
  src.ondrag = dragHandler;

  target.ondragenter = dragEnterHandler;
  target.ondragover = dragOverHandler;
  target.ondrop = dropHandler;

}

// get the xml list of senators
function loadFromXml() {
    var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                // call function to process senator data
                processXml(this);
              }
            };
            // https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/readystatechange_event
            xhr.open("GET", "partyList.xml", true);
            xhr.onreadystatechange = () => {
              // In local files, status is 0 upon success in Mozilla Firefox
              if (xhr.readyState === XMLHttpRequest.DONE) {
                const status = xhr.status;
                if (status === 0 || (status >= 200 && status < 400)) {
                  // The request has been completed successfully
                  console.log(xhr.responseText);
                  handleXml(xhr)
                } else {
                  console.log("error with XML request")
                }
              }
            };
            xhr.send();
        }


// creates JSON objects and stores the xml data locally
function handleXml(xml) {
    var senatorArr = [];
    var senatorXml = xml.responseXML;
    var senators = senatorXml.getElementsByTagName("senator");
    var list_member = '';

    // loop through xml
    for (var i = 0; i < senators.length; i++) { 
      var name = senators[i].getElementsByTagName("name")[0].childNodes[0].nodeValue;
      var party = senators[i].getElementsByTagName("party")[0].childNodes[0].nodeValue;

      // create JSON object and populate the array with it
      senatorArr.push({
            name: name,
            party: party,
            voted: false
      });
    }

    senatorArr.forEach(senator => {
        if(senator.party == 'Democrat'){
        list_member += `<li draggable='true' class='democrat' id="${senator.name}">` + senator.name + "</li>";}
        else if(senator.party == 'Republican'){
        list_member += `<li draggable='true' class='republican' id="${senator.name}">` + senator.name + "</li>";}
    });

    document.getElementById("members").innerHTML = list_member;

    document.getElementById("msg").innerHTML = "From AJAX Loaded " +
    senatorArr.length + " senators";
   
    // save as JSON to local storage in the browser
    localStorage.setItem('senators', JSON.stringify(senatorArr));    
}

// processes local storage data
function loadFromLocalStorage(senators) {
    var list_member = '';

    // loop through array to format output and make dragable if 'voted' set to false
    senators.forEach(senator => {
        if (senator.voted == true) {
            if (senator.party == 'Democrat'){
            // already voted so don't allow drag and drop
            list_member += `<li draggable='false' style="color:blue;" id="${senator.name}"><strike>` + senator.name + "</strike></li>";
            }else{
            list_member += `<li draggable='false' style="color:red;" id="${senator.name}"><strike>` + senator.name + "</strike></li>";
            }
        } else if(senator.voted == false) {

        if (senator.party == 'Democrat'){
            // already voted so don't allow drag and drop
            list_member += `<li draggable='true' style="color:blue;" id="${senator.name}"><strike>` + senator.name + "</strike></li>";
            }else{
            list_member += `<li draggable='true' style="color:red;" id="${senator.name}"><strike>` + senator.name + "</strike></li>";
            }
        }       
    });

    document.getElementById("members").innerHTML = list_member;

    document.getElementById("msg").innerHTML = "From LocalStorage Loaded " +
    senators.length + " senators";
};


function dragStartHandler(e) {
  e.dataTransfer.setData("Text", e.target.id);
  sourceId = e.target.id;
  e.target.classList.add("dragged");
}

function dragEndHandler(e) {
  msg.innerHTML = "Drag ended";
  var elems = document.querySelectorAll(".dragged");
  for(var i = 0; i < elems.length; i++) {
      elems[i].classList.remove("dragged");
  }
}

function dragHandler(e) {
  msg.innerHTML = "Dragging " + e.target.id;
}

function dragEnterHandler(e) {
  msg.innerHTML = "Drag Entering " + e.target.id;
  e.preventDefault();
}

function dragOverHandler(e) {
  var senator = findSenator(sourceId);

  msg.innerHTML = "Drag Over " + senator.name + " into " + e.target.id;
  e.preventDefault();  
}

function dropHandler(e) {
  console.log("Drop on " + e.target.id + 
           " source is " + e.dataTransfer.getData("Text")) ;
 
  var sourceElement = document.getElementById(sourceId);
  var newElement = sourceElement.cloneNode(true); // show in legend
  
  var senator = findSenator(sourceId);
  var politicalParty = e.target.id;

  // vote success -> update status
   if (politicalParty == 'republicans' && senator.party == 'Republican') {
         console.log(`Added ${senator.name} to republicans...`);
         republicans.appendChild(newElement);
         // can not vote with the same person
         sourceElement.setAttribute("draggable", "false");

         updateVoteStatusByName(senator);
     }
     else if (politicalParty == 'democrats' && senator.party == 'Democrat') {
         console.log(`Added ${senator.name} to democrats...`);
         democrats.appendChild(newElement);
         // can not vote with the same person
         sourceElement.setAttribute("draggable", "false");

         updateVoteStatusByName(senator);

     }
     else{
        alert(" CANNOT vote for the other party!")}

}

// lookup a senator by name
function findSenator(name) {
  // get localStorage
  var localStorageSenators = localStorage.getItem("senators");
  var senators = JSON.parse(localStorageSenators);
  // lookup a senators name
  for (var i = 0; i < senators.length; i++) {
    if (senators[i].name == name) {   
      return senators[i];
    }
  };
}


// update localStorage
function updateVoteStatusByName(senator) {
  var localStorageSenators = localStorage.getItem("senators");
  var senators = JSON.parse(localStorageSenators);
  
  // update vote to true, save back to localStorage
  for (var i=0; i < senators.length; i++) {
    if (senators[i].name == senator.name) {
        senators[i].voted = true;
        localStorage.setItem('senators', JSON.stringify(senators));
    }
  }  
}

// set senators who voted
function addSenatorsWhoVoted() {
  var senators = localStorage.getItem('senators');
  var senatorsArr = JSON.parse(senators);
  var votedAlready = [];
  var republicans = document.getElementById("republicans");
  var democrats = document.getElementById("democrats");
  var repubOutput = republicans.innerHTML;
  var demOutput = democrats.innerHTML;
 
  // create an array for senators who voted
  for (var i = 0; i < senatorsArr.length; i++) {
    if (senatorsArr[i].voted == true) {
      // create array of JSON objects to hold senators who voted
      votedAlready.push({
        name: senatorsArr[i].name,
        party: senatorsArr[i].party
      });
    }
  }
    // handle array
  for (var x = 0; x < votedAlready.length; x++) {
    if (votedAlready[x].party == 'Republican') {
      repubOutput += `<li draggable='false' class='republican' id="${votedAlready[x].name}">` + votedAlready[x].name + "</li>";
      republicans.innerHTML = repubOutput;
    }
    if (votedAlready[x].party == 'Democrat') {
      demOutput += `<li draggable='false' class='democrat' id="${votedAlready[x].name}">` + votedAlready[x].name + "</li>";
      democrats.innerHTML = demOutput;
    }    
  }

}