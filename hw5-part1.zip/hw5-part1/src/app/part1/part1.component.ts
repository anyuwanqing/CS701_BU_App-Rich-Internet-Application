import { Component, OnInit} from '@angular/core';


import { MapquestService } from 'src/services/mapquest.service';
import { Observable, Subject} from 'rxjs';

@Component({
  selector: 'app-part1',
  templateUrl: './part1.component.html',
  styleUrls: ['./part1.component.css']
})

export class Part1Component implements OnInit  {


  constructor(public mapService: MapquestService) {  }
  JSON_result: string;
  private searchProfile = new Subject<Array<string>>();

  //JSON_result: any;
  messages:any;

  ngOnInit() {
    this.searchProfile = new Subject<Array<string>>();


    this.searchProfile.pipe(
        () =>{
          return this.mapService.getPosts();
        }
      ).subscribe((result: any)=>{
        this.JSON_result = result;

        this.messages = result;

      })

  }


    }
	
	


