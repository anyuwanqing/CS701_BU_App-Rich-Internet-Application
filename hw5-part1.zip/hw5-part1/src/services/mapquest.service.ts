import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse} from '@angular/common/http';
import { Observable, pipe } from 'rxjs';
import {map} from 'rxjs/operators';
import { ComponentFactoryResolver } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MapquestService {

  constructor(private http: HttpClient) { }



  getPosts(): Observable<any> {

    let url: string = 'http://kalathur.com/getFacebookData.php'

    return this.http.jsonp(url, 'callback');



  }

}


