import { Component, OnInit } from '@angular/core';

// add router
import { Router, ActivatedRoute } from '@angular/router';



import { Contact } from '../../model/contact';
import { AddressProviderService } from 
		'../../model/address-provider.service';

@Component({
  selector: 'app-address-book',
  templateUrl: './address-book.component.html',
  styleUrls: ['./address-book.component.css']
})
export class AddressBookComponent implements OnInit {

	friends: Contact[];



  
  constructor
  (
    private provider: AddressProviderService,
    private router: Router) { }

  ngOnInit() {
  	this.friends = this.provider.getFriends();
  }


  // delete friend
  deleteFriend(friend: Contact) {
    console.log("deleting "+ friend.name);
    this.provider.deleteFriend(friend);
    this.router.navigate(['/']);
  }
}
