import { Injectable } from '@angular/core';

import { Contact } from './contact';
import { CONTACTS } from './mock-data';

@Injectable({
  providedIn: 'root'
})
export class AddressProviderService {

  constructor() { }


  // save a friend
  saveFriend(friend: Contact): void {
	let contacts:Contact[] = this.getFriends();
	let target = contacts.find(c => {return (c.id == friend.id)});
	if (!target) {
		contacts.push(friend);
	} else {
	console.log('target: ', target, 'friend: ', friend);
	Object.assign(target, friend);
  }
}


  // delete

    // remove a contact
	deleteFriend(friend: Contact) {
		if (confirm('You are about to delete: ' + friend.name)) {
		  // get all the contacts
		  const contacts:Contact[] = this.getFriends();
		  // loop through array and delete a contact
		  const index = contacts.indexOf(friend, 0);
		  if (index > -1) {
			console.log('Deleting: ' + friend.name);
			contacts.splice(index, 1);
		  }
		}
	  }

	  
  getFriends(): Contact[] {
  	return CONTACTS;
  }

  getFriend(id: number): Contact{
  	let friends = this.getFriends();
    let friend = friends.find(
    		f => {return (f.id == id)});
	if(friend){
		return friend;
	}else{
		return friends[0];
	}
  }

  addFriend(): Contact {
  	let friends:Contact[] = this.getFriends();
  	let maxId: number;
  	
  	if (friends && friends.length > 0) {
  		maxId = friends[friends.length - 1].id;	
  	} else {
  		maxId = 0;
  	}

  	let friend = new Contact();
  	friend.id = maxId + 1;
  	friends.push(friend);
  	return friend;
  }

}
