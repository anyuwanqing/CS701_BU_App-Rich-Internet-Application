var rotationsModule = (function() {

	function changeSpeed() {

        var time_one_cycle = document.getElementById("duration").value;
	    document.getElementById("durationDisplay").value = time_one_cycle + 's';

	    // Fill in the rest of the code to change the dur attributes of the four animations
		// get all stopsigns
		var stopsigns = document.getElementsByTagName('animateTransform');

        // set all to new time
		for (var i = 0; i < stopsigns.length; i++) {
			//setting the duration attribute for each one to the slider value
			stopsigns[i].setAttribute('dur', time_one_cycle);
		}
	}

	return {
        changeSpeed: changeSpeed
    };

})();