var animModule = (function() {

    window.onload = init;

    var canvas;
    var context;
    var width, height;

    var ballRadius = 10;
    var ballColor = "blue";
    var ballPosition;
    var startBallPosition;
    var angle = 0;

    // displacement of ball for each step x an y
    var dx = 5;


    // 405 / 16 = 25.3,  so
    const line_height = 25.31;
    var dy = line_height;

    function init() {

        canvas = document.getElementById('testCanvas');
        context = canvas.getContext('2d');

        width = canvas.width;
        height = canvas.height;

        // current ball position
        ballPosition = {x : ballRadius, y : ballRadius + 5};

        // start position
        startBallPosition = {x : ballRadius, y : ballRadius + 5};

    }

    function setSpeed(speed) {
        let newSpeed = +speed;
        if (dx > 0) {
            dx = newSpeed
        }
        else {
            dx =  -newSpeed;
        }


        //variable to control the forward displacement of the ball
        let speedChanged = true
        console.log(dx)
        console.log(ballPosition.x)
    }


    function drawLines(){
            //draw lines:
            //  16 lines, 8 from left and 8 from right, leave space = 3* ball radius
            for (var i=0; i<8; i++){

                if(i==0){
                                context.beginPath();
                                context.lineWidth = 2;
                                context.moveTo(0,line_height);
                                context.lineTo(403-3*ballRadius, line_height);
                                context.stroke();
                                context.closePath()

                                context.beginPath();
                                context.lineWidth = 2;
                                context.moveTo(405, 2*line_height);
                                context.lineTo(ballRadius*3, 2*line_height);
                                context.stroke();
                                context.closePath()
                    }else{
                                context.beginPath();
                                context.lineWidth = 2;
                                context.moveTo(0,(1+2*i)*line_height);
                                context.lineTo(403-3*ballRadius, (1+2*i)*line_height);
                                console.log(i+3);
                                console.log('h=' + (i+2)*line_height);
                                context.stroke();
                                context.closePath()

                                context.beginPath();
                                context.lineWidth = 2;
                                context.moveTo(405, (2+2*i)*line_height);
                                context.lineTo(ballRadius*3, (2+2*i)*line_height);
                                context.stroke();
                                context.closePath()
                    }
            }
    }

    // draw current position on the canvas
    function drawBallOnCanvas() {

        // Clear the canvas

        context.fillStyle = '#D3C0C0';
        context.fillRect(0, 0, canvas.width, canvas.height);

        // Fill in the rest of the code

        // first draw lines
        drawLines();


            function updateBallPosition() {
                context.beginPath();
                context.fillStyle = ballColor;
                context.arc(ballPosition.x,ballPosition.y, ballRadius, angle, 2 * Math.PI, true);
                context.fill();
                context.closePath();

                //what moves the ball from the start
                ballPosition.x += dx;

                //prevent ball going to y>390, and drop it
                if (ballPosition.x > 390) {
                    // drop  the ball
                    ballPosition.y += dy;
                    //reverse dx
                    dx = -dx;
                    ballPosition.x += dx;
                    ballColor = 'red';
                }
                //prevent ball going to negative x
                if (ballPosition.x < 5 && ballPosition.y !== startBallPosition.y) {
                    //move the ball up the y axis
                    ballPosition.y += dy;
                    dx = -dx;
                    ballPosition.x += dx;
                    ballColor = 'blue';
                }

                // reset ball after the last line
                if (ballPosition.y >= 400) {
                    ballPosition.x = ballRadius/2;
                    ballPosition.y = line_height-ballRadius;
                    ballColor = 'blue';
                }
            }
            updateBallPosition();

    }


    // browser specific animation request
     window.requestAnimFrame = (function(){
          return  window.requestAnimationFrame       ||
                  window.webkitRequestAnimationFrame ||
                  window.mozRequestAnimationFrame    ||
                  window.oRequestAnimationFrame      ||
                  window.msRequestAnimationFrame     ||
                  // fall back to JavaScript setTimeout
                  function(callback, element){
                    window.setTimeout(callback, 1000 / 60);
                  };
        })();

        // Define the Animation
        function doAnimation() {
            // Draw a single frame of animation on our canvas
            drawBallOnCanvas();

            // After this frame is drawn, let the browser schedule the next one
            window.requestAnimFrame(doAnimation);
        }

        // Start the Animation

         window.requestAnimFrame(doAnimation);

         return {
            setSpeed: setSpeed
         }
})();