var bullsEye = (function(win, doc) {

    win.onload = init;

// canvas.beginpath()
//Paths are used for drawing arbitrary shapes on the canvas

   // canvas and context variables
    var canvas;
    var context;

    // center of the pattern
    var centerX, centerY;

    // delay
    var slow_speed_showing = false;

    // Interval
    var timerId;

// after window loading, add listener to see if to delay showing
window.addEventListener("DOMContentLoaded", (event) => {
    const el = document.getElementById('delay');
    if (el) {
      el.addEventListener('click', delay, false);
    }
    function delay(){
        console.log('delay showing: yes');
        slow_speed_showing = true;
    }
});


    function init() {
        canvas = doc.getElementById("pattern");
        context = canvas.getContext("2d");

        centerX = canvas.width / 2;
        centerY = canvas.height / 2;

        drawPattern();
    }


    // called whenever the slider value changes or the delay checkbox is clicked
    function drawPattern() {

        context.clearRect(0, 0, canvas.width, canvas.height);
        //get the band
        var band = doc.getElementById("band").value;
        console.log('band' + band);
        //display band width
        doc.getElementById("current_width").innerHTML = band;

        // delay second
        if (timerId) {
            clearInterval(timerId);
            timerId = undefined;
        }

        context.clearRect(0, 0, canvas.width, canvas.height);

        var timer = 0;
        var bandWidth = band;
        var new_width = 170;
        var current_color;

        // if delay, 1.5 sec
        // delay showing: use setInterval() to add 1.5s intervals between each circle
        if(slow_speed_showing == true){
			timer = 1500;
		}

        timerId = setInterval(() => {
        if(new_width > 0){

            if(current_color == "blue"){
                current_color = "red";
            }else if(current_color == "red") {
                current_color = "blue";
            }else{
                current_color = "red";
            }

            // draw circle
            //   for new circle: new radius is current radius - band width
            context.lineWidth = 3;
            context.beginPath();
            context.arc(centerX,centerY, new_width ,0, 2 * Math.PI, true);
            context.fillStyle = current_color;
            context.fill();
            context.closePath();
            new_width = new_width - bandWidth;
        }
        }, timer);
    }

    return {
        drawPattern: drawPattern
    }

})(window, document);