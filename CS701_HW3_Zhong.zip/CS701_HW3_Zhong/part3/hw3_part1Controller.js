/*
General idea is to create a snapshot each time an action is performed,
like history copies.
undo is to revert to previous copy, while redo go to future copies,
when any action (add or remove) increases the snapshot_index, (create copy)
undo decreases the index, (return to previous history)
redo increases the index. (return to state before last undo)

This method differs from the stack method and uses index, and is very heavy on memory,
while the stack methods simply use pop and push to keep track of modifications to original books,
with a type === 'add' or 'remove', and undo does the opposite,
however when I debugged with one undo stack and one redo stack, the redo function does not work properly
*/


angular.module('myApp', [])
.controller('CartControler', function ($scope) {

// keep track of current copy index
var snapshot_index = 0;

// all copies
var all_copies = [];
var defaultBooks;

// for Debugging purposes delete local storage first
window.localStorage.removeItem('part3');


	if (localStorage.getItem("part3") == null){
		  defaultBooks = [
        {title: 'Absolute Java', qty: 1, price: 114.95},
        {title: 'Pro HTML5',     qty: 2, price: 27.95},
        {title: 'Head First HTML5', qty: 1, price: 27.89}
      ];

      $scope.books = defaultBooks;
	}

	else{
	// use local storage
		defaultBooks = JSON.parse(localStorage.part3);
		$scope.books = defaultBooks;
	}

	// add a default 'new book' book and increase the current copy index
   $scope.addBook = function() { //Add the book to store
          if(all_copies.length > snapshot_index){
              all_copies.length = snapshot_index; }

          var current_copy = [];
          // push all into data
          angular.forEach($scope.books, function(book){
              current_copy.push({title: book.title, qty: book.qty, price:book.price});
          });

          all_copies.push(current_copy);

           window.localStorage.setItem('part3',JSON.stringify(all_copies));

           snapshot_index++;

          defaultBooks.push({
          title: "new book",
          qty: 1,
          price: 10.99});

          return defaultBooks;
      }

       // remove and increase index
      $scope.removeBook = function(index) {
		   if(all_copies.length > snapshot_index){
			  all_copies.length = snapshot_index;
		  }

		  var current_copy = [];

		   angular.forEach($scope.books, function(book){ //Iterate through each book
			  var elements =
			  current_copy.push({title: book.title, qty: book.qty, price:book.price});
		  });

		  all_copies.push(current_copy);
		  // save
		  window.localStorage.setItem('part3',JSON.stringify(all_copies)); //Store list of list inside the local storage
		  snapshot_index++;

		  defaultBooks.splice(index,1); //remove book at this index
      }


    // undo and decrease index
	  $scope.undo = function(){
		  if(snapshot_index < 0){
		    alert("Error! can't undo because there is no copy to return to");

            }else{
			   var current_copy = [];

		  angular.forEach($scope.books, function(book){
			  current_copy.push({title: book.title, qty: book.qty, price:book.price});
		  });

		  all_copies.push(current_copy);

		  snapshot_index--;

		  // return to the previous copy
			defaultBooks = JSON.parse(localStorage.part3)[snapshot_index];
			$scope.books = defaultBooks;

			// save
			window.localStorage.setItem('part3',JSON.stringify(all_copies));
		  }

	  }

    // redo and increase index
      $scope.redo = function() {
		  if(snapshot_index < all_copies.length && snapshot_index >= 0){

			   var current_copy = [];

		   angular.forEach($scope.books, function(book){
			  current_copy.push({title: book.title, qty: book.qty, price:book.price});
		  });

		  all_copies.push(current_copy);
          snapshot_index++;

          // return to the newest copy
          defaultBooks = JSON.parse(localStorage.part3)[snapshot_index];
          $scope.books = defaultBooks;

			// save
			window.localStorage.setItem('part3',JSON.stringify(all_copies));
		  }
		  else{
			  alert("Error! can't redo because there is no copy to go to")
		  }
	  }


    // save to local
      $scope.saveBooks = function() {
		  window.localStorage.setItem('part3',JSON.stringify(defaultBooks));
		  return defaultBooks;
      }

      $scope.updateTotal = function() {
          var total = 0;
          angular.forEach($scope.books, function(book){
			  if(book.title){
			      total = total + (book.price * book.qty);}
		  });
          return total;
      }
    }

);