angular.module('myApp', [])
.controller('CartControler', function ($scope) {


    if (localStorage.getItem("part1") == null){
    var defaultBooks = [
        {title: 'Absolute Java', qty: 1, price: 114.95},
        {title: 'Pro HTML5',     qty: 2, price: 27.95},
        {title: 'Head First HTML5', qty: 1, price: 27.89}
      ];

          $scope.books = defaultBooks;
      }else{
          defaultBooks = JSON.parse(localStorage.part1)
          $scope.books = defaultBooks;
      }

      $scope.removeBook = function(index) {
          defaultBooks.splice(index, 1);
      }

      $scope.addBook = function() {
          defaultBooks.push({
          title: "new book",
          qty: 1,
          price: 10.99});

          return defaultBooks
      }

      // save to local storage
      $scope.saveBooks = function() {
            window.localStorage.setItem("part1",JSON.stringify(defaultBooks));
            return defaultBooks
      }

      $scope.updateTotal = function() {
          var total = 0;
          angular.forEach($scope.books,
          function(books){
              if (book.title){
              total = total + (book.qty* book.price)}
          })

          return total;
      }


    }
);
