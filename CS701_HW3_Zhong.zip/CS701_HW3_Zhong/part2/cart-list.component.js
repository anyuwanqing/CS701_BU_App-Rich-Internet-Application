angular.module("cartApp")
  .component('cartList', {
    templateUrl: 'cart-list/cart-list.template.html',
    controller: function CartListController() {

      var defaultBooks = [
        {title: 'Absolute Java', qty: 1, price: 114.95},
        {title: 'Pro HTML5',     qty: 2, price: 27.95},
        {title: 'Head First HTML5', qty: 1, price: 27.89}
      ];


          if (localStorage.getItem("part2") == null){
      		  this.defaultBooks = defaultBooks;
      			}


      	else{
      		this.defaultBooks = JSON.parse(localStorage.part2);

      	}

      
      this.removeBook = function(index) {
		  this.defaultBooks.splice(index,1);
      }

      this.addBook = function() {
		  this.defaultBooks.push({title: "New Book", qty: 1, price: 10.99});
		  return this.defaultBooks;
      }

      this.saveBooks = function() {

        // save to local storage
		  window.localStorage.setItem('part2',JSON.stringify(this.defaultBooks)); //Save to local storage

		  return this.defaultBooks;
      }

      this.updateTotal = function() {
          var total = 0;

        // calculate tot
           angular.forEach(this.defaultBooks, function(book){
			  if(book.title){
			      total = total + (book.price * book.qty);
			      }

		  });

          return total;

      }


    }
  });