// Define the module

angular.module('cartApp', []);