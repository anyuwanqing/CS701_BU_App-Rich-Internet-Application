import { Pipe, PipeTransform, ViewChild } from '@angular/core';

@Pipe({
  name: 'tokenizer'
})

export class TokenizerPipe implements PipeTransform {
	

  transform(value: any, delimiter?: any): any {
	  if((delimiter !== ',') && (typeof value === 'string')){

		var result_after_split = value.split('');
		return result_after_split.join(delimiter);
	  }
	  else{
		return value.split('').join(',');
	  }
	 
  }
  
  

}


