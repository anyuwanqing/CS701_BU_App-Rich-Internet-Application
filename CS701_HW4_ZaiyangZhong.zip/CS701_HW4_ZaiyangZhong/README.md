# CS701HW4ZaiyangZhong

Generated with Angular Cli.

## INSTALL

Node.js and npm (If not installed)
  https://nodejs.org/en/download/
    Use the appropriate installer for your OS.

Angular CLI
  
  MAC:
     sudo npm install -g @angular/cli
  
  Windows (From Command Window with Administrator Privilege):
     npm install -g @angular/cli

Reference for Angular CLI: 
https://cli.angular.io/


## MAC INSTALLATION DEBUGGING

	NPM INSTALLATION PROBLEM WITH MAC
	https://stackoverflow.com/questions/58138138/angular-cli-ng-command-not-found-on-mac-os

	USING ANGULAR
	ng update @angular/cli @angular/core --allow-dirty --force

	# run TS file
	tsc   xxx.ts


	- Npm install
	- Ng server
	- Go to localhost/4200



## Build

After installing Node (npm) and Angular, in terminal of file directory

Run `npm install` to install node_modules

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.




## Composition
The server has 2 parts, the first part is an implement of HW3 - part 2 cart in TypeScript; 
Second part is a tokenizer that adds a delimiter to a string.




# Running
Run `ng serve` to have server at  https://localhost:4200









## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
